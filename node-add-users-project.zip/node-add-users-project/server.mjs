import { createServer } from "http";
import routes from './routes.mjs';

const server = createServer(routes);

server.listen(3000);