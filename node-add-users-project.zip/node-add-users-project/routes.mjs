import fs from 'fs';

const routes = (req, res) => {
    const url = req.url;
    const method = req.method;

    if (url === '/') { //index page

        res.setHeader('Content-Type', 'text/html');

        const html = `
            <div>
            <h3>Welcome User, Please add new users below - </h3>
                <form action='/create-user' method='POST'>
                    <input type="text" name="username" />
                    <input type="submit" value="Add Users" />
                </form>
            </div>
        `;
        res.write(html);
        return res.end();

    }

    if (url === '/users') {

        res.setHeader('Content-Type', 'text/html');
        
        const html = `
            <div>
                <ul>
                    <li>User One</li>
                    <li>User Two</li>
                    <li>User Three</li>
                </ul>
            </div>
        `;
        res.write(html);
        return res.end();

    }

    if (url === '/create-user' && method === 'POST') {
        const body = [];
        req.on('data', (chunk) => {
            body.push(chunk);
        });

        return req.on('end', () => {
            const parsedBody = Buffer.concat(body).toString();
            const userName = parsedBody.split('=')[1];

            fs.writeFile('all-users.txt', userName, () => {

                res.setHeader('Location', '/users');
                res.statusCode = '302';

                return res.end();

            });


        });
    }
}

export default routes;